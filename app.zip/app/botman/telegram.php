<?php

  return[
    'token' => env('TELEGRAM_TOKEN'),

  ]
?>
