<?php


   return [
    'blogs'=>'blogs',
    'add blog'=>'add blog',
    'Dashboard'=>'dashbpard',

    'image'=>'image',
    'title'=>'title',
    'actions'=>'Actions',

    'main title'=>'main title',
    'sub title'=>'sub title',

    'main description'=>'main description',
    'sub description'=>'sub description',
    'save'=>'save',
    'delete'=>'delete',



     ////blogs
     'my teams'=>'my teams',
     'add team'=>'add team',
     'job'=>'job',
     'name'=>'name',
     'edit team'=>'edit team',
     'close'=>'close',

     ////jobs
     'jobs'=>'jobs',
     'email'=>'email',
     'nationality'=>'nationality',
     'phone'=>'phone',
     'message'=>'message',
     'cv'=>'cv',

     'mailing lists'=>'mailing lists',

     'requests'=>'requests',
     'type service'=>'type service',

     'caontact us'=>'caontact us',
     'products'=>'products',
     'add product'=>'add product',

     'english name'=>'english name',
     'arabic name'=>'arabic name',
     'arabic description' =>'arabic description',
     'english description'=>'english description',
     'product idea '=>'product idea',

     'type'=>'type',
     'link'=>'link',


    'english product name'=>'english product name',
    'arabic product name '=>'arabic product name',
    'arabic idea product' =>'arabic idea product',
    'english idea  product'=>'english idea  product',


     'categories'=>'categories',
     'add category'=>'add category',
     'edit category'=>'edit category',

     'add my works'=>'add my works',
     'my works'=>'my works',
     'upload image'=>'upload image',
     'subject '=>'subject',

     'mobile'=>'mobile',
     'web'=>'web',
     'nothing'=>'nothing',

     'link google play'=>'link google play',
     'link app store'=>'link app store',
     'link website'=>'link website',

     'select category'=>'select category',

     'customer-reviews'=>'customer-reviews',
     'add customer-reviews'=>'add customer-reviews'


   ]
?>
